"use strict"

let chamber = document.querySelector("#house") ? "house" : "senate"

let URLAPI = `https://api.propublica.org/congress/v1/113/${chamber}/members.json`

let init = {
    method : "GET",
    headers: {
        "X-API-Key":"7AzXitjcZX5gKTc4xDvLSSDJ5RmvvIIFaAVYSN49"
    }
}

fetch (URLAPI, init)
    .then(response => response.json())
        .then(datos => {
            let data = datos
            console.log(data)

// EXERCISE B

const membersSenate = (arrayMembers) => {
    
    arrayMembers.results[0].members.forEach(element => {
        if (element.middle_name != null) {
            console.log(`${element.first_name} ${element.middle_name} ${element.last_name}`)
        } else {
            console.log (`${element.first_name} ${element.last_name}`)
        }

    });
};

membersSenate(data)

// EXERCISE C

const statesSenate = (arrayMembers2) => {

    let statesWithoutRepeat= []

    arrayMembers2.results[0].members.forEach(element => {

        if (!statesWithoutRepeat.includes(element.state)) {

            statesWithoutRepeat.push(element.state)
        }
    });
    console.table(statesWithoutRepeat.sort())
    
    return statesWithoutRepeat
};

statesSenate(data)

// EXERCISE D

const partysConsole = (arrayParty, partyName) => {

    let names = []

    arrayParty.results[0].members.forEach(element => {
        
        if (element.party.includes(partyName)) {

            if (element.middle_name != null) {
                names.push(`${element.first_name} ${element.middle_name} ${element.last_name}`)
            } else {
                names.push(`${element.first_name} ${element.last_name}`)
            }

        }
        
    });
    return names
}

partysConsole(data, "D")

// EXERCISE E

// const statesConsole = (arrayState, stateName) => {

//     let namesState = []

//     arrayState.results[0].members.forEach(element => {
        
//         if (element.state.includes(stateName)) {

//             if (element.state.includes(stateName)) {

//                 if (element.middle_name != null) {
//                     namesState.push(`${element.first_name} ${element.middle_name} ${element.last_name}`)
//                 } else {
//                     namesState.push(`${element.first_name} ${element.last_name}`)
//                 }
    
//             }

//         }
        
//     });
//     console.table (namesState)
// }

// statesConsole(data, "NH")

const showState = (arrayState) => {
    let listState =[]
    arrayState.results[0].members.forEach(element => {
        if (!listState.includes(element.state)) {
            listState.push(element.state)
        }
    })
    return listState
}


// Tarea 2 DOM


const renderMembers = (array) => {

    let table = document.querySelector("#politicianTable")
    
    table.innerHTML = ""
    
    array.forEach(member => {
        let itemOfList = document.createElement("tr")
        itemOfList.innerHTML=
        `
        <td>
        <a href="${member.url}" style= "text-decoration: 1px lightblue underline"">
            ${member.first_name}
            ${member.middle_name ? member.middle_name : ""}
            ${member.last_name}
            </a>
        </td>
        <td>${member.party}</td>
        <td>${member.state}</td>
        <td>${member.seniority}</td>
        <td>${member.votes_with_party_pct}%</td>
        `
        table.appendChild(itemOfList)
    })

}

let form = document.querySelector("form")

const stateSelect = form.querySelector("#select-id")

form.addEventListener("change", () => {
    
    let checksForm = document.querySelectorAll("input[type='checkbox']")
    
    let checksForFilter = Array.from(checksForm)
    
    let filtrated = checksForFilter.filter(checkbox => checkbox.checked)
    
    let valuesOfFiltrate = filtrated.map(checkbox => checkbox.value)

    console.log(valuesOfFiltrate)
    
    let aux = []

    const filteringParty = () => {
        if (valuesOfFiltrate.length == 0) {
            aux = data.results[0].members
        } else {
            data.results[0].members.forEach(miembro =>
                valuesOfFiltrate.forEach(check => miembro.party == check ? aux.push(miembro) : ""))
                
        }
        
        renderMembers(aux)
    }
    filteringParty()
    
    let selectedOption = stateSelect.value
    console.log(selectedOption)
    
    
    const filteringState = () => {
        
        let auxStates = []
        
        aux.forEach (member => {
            if (selectedOption == "all") {
                auxStates.push(member)
            } else  if (selectedOption == member.state){
                auxStates.push(member)
            }
        })
        renderMembers (auxStates)
    }

    filteringState()

})


const renderStates = (optionsStates) => {
    optionsStates.forEach(state => {
        let stateOption = document.createElement("option")
        stateOption.innerHTML = `${state}`
        stateOption.value = `${state}`
        stateSelect.appendChild(stateOption)
    });
}
renderStates (showState(data).sort())

renderMembers(data.results[0].members)

})