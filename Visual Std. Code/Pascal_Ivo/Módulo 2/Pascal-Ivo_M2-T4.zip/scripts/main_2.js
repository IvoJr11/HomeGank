
let chamber = document.querySelector("#house") ? "house" : "senate"

let URLAPI = `https://api.propublica.org/congress/v1/113/${chamber}/members.json`

let init = {
    method : "GET",
    headers: {
        "X-API-Key":"7AzXitjcZX5gKTc4xDvLSSDJ5RmvvIIFaAVYSN49"
    }
}

fetch (URLAPI, init)
    .then(response => response.json())
        .then(datos => {
        const data = datos
        console.log(data)
    
    
    // const partidosSeparados = (array, party) => {
        //     let filtrandoPartidos = array.results[0].members.filter(member => member.party == party)
        //     return filtrandoPartidos
        // }
        // let cantidadDemocratas = partidosSeparados(data, "D")
        // let cantidadRepublicanos = partidosSeparados(data, "R")
        // let cantidadIndependientes = partidosSeparados(data, "ID")
        


let miembrosDemocratas = 0
let miembrosRepublicanos = 0
let miembrosIndependentistas = 0
var sumaDePorcentajesDemocratas = 0
var sumaDePorcentajesRepublicanos = 0
var sumaDePorcentajesIndependentistas = 0
var sumaDePorcentajes = 0

data.results[0].members.forEach(miembro => {
    if (miembro.party === "D") {
        miembrosDemocratas ++
        sumaDePorcentajesDemocratas = sumaDePorcentajesDemocratas + miembro.votes_with_party_pct
    } else if(miembro.party === "R") {
        miembrosRepublicanos ++
        sumaDePorcentajesRepublicanos = sumaDePorcentajesRepublicanos + miembro.votes_with_party_pct
    } else if (miembro.party === "ID") {
        miembrosIndependentistas ++
        sumaDePorcentajesIndependentistas = sumaDePorcentajesIndependentistas + miembro.votes_with_party_pct
    }
    sumaDePorcentajes = sumaDePorcentajes + miembro.votes_with_party_pct
});

let total = miembrosDemocratas + miembrosRepublicanos + miembrosIndependentistas

const imprimirTabla = () => {

    let percentByPartyD = (sumaDePorcentajesDemocratas/miembrosDemocratas)
    let percentByPartyR = (sumaDePorcentajesRepublicanos/miembrosRepublicanos)
    let percentByPartyID = (sumaDePorcentajesIndependentistas/miembrosIndependentistas)

    if (isNaN(percentByPartyID)) {
        percentByPartyID = 0
    }


    let tableAttendance = document.querySelector("#tbody_attendance")

    tableAttendance.innerHTML = `
    <tr>
    <td>Democrats</td>
    <td>${miembrosDemocratas}</td>
    <td>${percentByPartyD.toFixed(2)}&#37;</td>
    </tr>
    <tr>
    <td>Republicans</td>
    <td>${miembrosRepublicanos}</td>
    <td>${percentByPartyR.toFixed(2)}&#37;</td>
    </tr>
    <tr>
    <td>Independents</td>
    <td>${miembrosIndependentistas}</td>
    <td>${percentByPartyID.toFixed(2)}&#37;</td>
    </tr>
    <tr>
    <tr>
    <td>Total</td>
    <td>${total}</td>
    <td>${(sumaDePorcentajes/total).toFixed(2)}&#37;</td>
    </tr>
    `

}

imprimirTabla()

// PLANTEAMIENTO "ERRÓNEO"
// const tablaEngaged = () => {

    
//     let votosFallidos = ruta.map(function(member){
        
//         return member.missed_votes
        
//     }).sort(function(a , b){return a - b})
    
//     let diezPorCien = Math.round((total*10)/100)

//     console.log(diezPorCien)

//     let porcientoMenor = votosFallidos.slice (0, diezPorCien)

//     let porcientoMenorMasUno = votosFallidos.slice(diezPorCien, votosFallidos.length)

//     porcientoMenorMasUno.forEach (number => {
//         if (number == porcientoMenor[porcientoMenor.length]) {
//             porcientoMenor.push(number)
//         }
//     })

//     console.log(porcientoMenorMasUno)

//     console.log(porcientoMenor)

//     console.log (votosFallidos)


//     let cantidadMenor= []

//     for (let i=0; i<Number(porcientoMenor) + 1; i++) {
//         for (let j=i; j<ruta.length; j++){
//             if (votosFallidos[i] === ruta[j].missed_votes) {
//                 if (!cantidadMenor.includes(ruta[j]))
//                 cantidadMenor.push(ruta[j])
//             }
//         }
//     }

//     console.log(cantidadMenor)

// }

// tablaEngaged()


let auxPorcentaje = []           

data.results[0].members.forEach(member => {
if (!auxPorcentaje.includes(member.votes_with_party_pct)) {

    auxPorcentaje.push(member)

}
auxPorcentaje.sort(function (a, b){return a.missed_votes_pct - b.missed_votes_pct})
})

console.log(auxPorcentaje)

let reglaDeTres = Math.floor(total*0.10)

console.log(reglaDeTres)

let ordenadoFinalMost = auxPorcentaje.slice(0, reglaDeTres)
let ordenadoFinalLeast = auxPorcentaje.reverse().slice(0, reglaDeTres)

console.log (ordenadoFinalLeast)
console.log (ordenadoFinalMost)

let capturandoId = document.querySelector("#tableEngaged")

let capturandoId_2 = document.querySelector("#tableLost")


const tablaEngaged = (array, idTabla) => {
    
    let tableEngaged = document.querySelector(`#${idTabla}`)

    array.forEach(member => {
        let creandoMiembro = document.createElement("tr")
        creandoMiembro.innerHTML = `
        <td>
            <a href="${member.url}" style= "text-decoration: 1px lightblue underline"">
            ${member.first_name}
            ${member.middle_name ? member.middle_name : ""}
            ${member.last_name}
            </a>
        </td>
        <td>${member.missed_votes}</td>
        <td>${member.missed_votes_pct.toFixed(2)}&#37;</td>
        `

        tableEngaged.appendChild(creandoMiembro)

    })

}

if (capturandoId) {
    tablaEngaged(ordenadoFinalMost, "tableEngaged_2")
    tablaEngaged(ordenadoFinalLeast, "tableEngaged")
}

const tablaRoyalty = (array, idTabla) => {

    let tableRoyalt = document.querySelector(`#${idTabla}`)

    array.forEach(member => {
        let creandoMiembroR = document.createElement("tr")
        creandoMiembroR.innerHTML = `
        <td>
            <a href="${member.url}" style= "text-decoration: 1px lightblue underline"">
            ${member.first_name}
            ${member.middle_name ? member.middle_name : ""}
            ${member.last_name}
            </a>
        </td>
        <td>${Math.round((total/100)*member.votes_with_party_pct)}</td>
        <td>${member.votes_with_party_pct}&#37;</td>
        `

        tableRoyalt.appendChild(creandoMiembroR)

    })

}

if (capturandoId_2) {
    tablaRoyalty(ordenadoFinalMost, "tableLost")
    tablaRoyalty(ordenadoFinalLeast, "tableMost")
}

})
.catch(error => console.warn(error.message))