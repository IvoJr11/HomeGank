
let URLAPI = `https://api.propublica.org/congress/v1/113/senate/members.json`

let init = {
    method : "GET",
    headers: {
        "X-API-Key" : "7AzXitjcZX5gKTc4xDvLSSDJ5RmvvIIFaAVYSN49"
    }
}

fetch (URLAPI, init)
.then(response => response.json())
.then(datos => {
    let data = datos
    console.log(data)



// const partidosSeparados = (array, party) => {
//     let filtrandoPartidos = array.results[0].members.filter(member => member.party == party)
//     return filtrandoPartidos
// }
// let cantidadDemocratas = partidosSeparados(data, "D")
// let cantidadRepublicanos = partidosSeparados(data, "R")
// let cantidadIndependientes = partidosSeparados(data, "ID")
// var ruta = data.results[0].members

let miembrosDemocratas = 0
let miembrosRepublicanos = 0
let miembrosIndependentistas = 0
var sumaDePorcentajesDemocratas = 0
var sumaDePorcentajesRepublicanos = 0
var sumaDePorcentajesIndependentistas = 0
var sumaDePorcentajes = 0

data.results[0].members.forEach(miembro => {
    if (miembro.party === "D") {
        miembrosDemocratas ++
        sumaDePorcentajesDemocratas = sumaDePorcentajesDemocratas + miembro.votes_with_party_pct
    } else if(miembro.party === "R") {
        miembrosRepublicanos ++
        sumaDePorcentajesRepublicanos = sumaDePorcentajesRepublicanos + miembro.votes_with_party_pct
    } else if (miembro.party === "ID") {
        miembrosIndependentistas ++
        sumaDePorcentajesIndependentistas = sumaDePorcentajesIndependentistas + miembro.votes_with_party_pct
    }
    sumaDePorcentajes = sumaDePorcentajes + miembro.votes_with_party_pct
});

let total = miembrosDemocratas + miembrosRepublicanos + miembrosIndependentistas

const imprimirTabla = () => {

    let percentByPartyD = (sumaDePorcentajesDemocratas/miembrosDemocratas)
    let percentByPartyR = (sumaDePorcentajesRepublicanos/miembrosRepublicanos)
    let percentByPartyID = (sumaDePorcentajesIndependentistas/miembrosIndependentistas)

    if (isNaN(percentByPartyID)) {
        percentByPartyID = 0
    }

    let tableAttendance = document.querySelector("#tbody_attendance")

    tableAttendance.innerHTML = `
    <tr>
    <td>Democrats</td>
    <td>${miembrosDemocratas}</td>
    <td>${percentByPartyD.toFixed(2)}&#37;</td>
    </tr>
    <tr>
    <td>Republicans</td>
    <td>${miembrosRepublicanos}</td>
    <td>${percentByPartyR.toFixed(2)}&#37;</td>
    </tr>
    <tr>
    <td>Independents</td>
    <td>${miembrosIndependentistas}</td>
    <td>${percentByPartyID.toFixed(2)}&#37;</td>
    </tr>
    <tr>
    <tr>
    <td>Total</td>
    <td>${total}</td>
    <td>${(sumaDePorcentajes/total).toFixed(2)}&#37;</td>
    </tr>
    `

}

imprimirTabla()


let auxPorcentaje = []           

data.results[0].members.forEach(member => {
if (!auxPorcentaje.includes(member.votes_with_party_pct)) {

    auxPorcentaje.push(member)

}
auxPorcentaje.sort(function (a, b){return a.votes_with_party_pct - b.votes_with_party_pct})
})


console.log(auxPorcentaje)

let reglaDeTres = Math.floor(total*0.10)

console.log(reglaDeTres)

let ordenadoFinalMost = auxPorcentaje.slice(0, reglaDeTres)
let ordenadoFinalLeast = auxPorcentaje.reverse().slice(0, reglaDeTres)


const tablaRoyalty = (array, idTabla) => {

    let tableRoyalty = document.querySelector(`#${idTabla}`)

    array.forEach(member => {
        let creandoMiembroR = document.createElement("tr")
        creandoMiembroR.innerHTML = `
        <td>
            <a href="${member.url}" style= "text-decoration: 1px lightblue underline"">
            ${member.first_name}
            ${member.middle_name ? member.middle_name : ""}
            ${member.last_name}
            </a>
        </td>
        <td>${Math.round((total/100)*member.votes_with_party_pct)}</td>
        <td>${member.votes_with_party_pct}&#37;</td>
        `

        tableRoyalty.appendChild(creandoMiembroR)
        
    })

}

tablaRoyalty(ordenadoFinalMost, "tableRoyaltyL")
tablaRoyalty(ordenadoFinalLeast, "tableRoyaltyM")

})
.catch(error => console.warn(error.message))