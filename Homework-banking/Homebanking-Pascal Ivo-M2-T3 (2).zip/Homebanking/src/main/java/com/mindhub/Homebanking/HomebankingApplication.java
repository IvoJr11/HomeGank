package com.mindhub.Homebanking;

import com.mindhub.Homebanking.models.Account;
import com.mindhub.Homebanking.models.Client;
import com.mindhub.Homebanking.models.Transaction;
import com.mindhub.Homebanking.models.Type;
import com.mindhub.Homebanking.repositories.AccountRepository;
import com.mindhub.Homebanking.repositories.ClientRepository;
import com.mindhub.Homebanking.repositories.TransactionRepository;
import org.apache.tomcat.jni.Local;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;

@SpringBootApplication
public class HomebankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomebankingApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(ClientRepository repository1, AccountRepository repository2, TransactionRepository repository3) {
		return (args) -> {

			Client Cliente1 = new Client("Melba", "Morel", "melba@mindhub.com");
			Client  Cliente2= new Client ("Pedro", "Hernández", "pedrohf@gmail.com");

			repository1.save(Cliente1);
			repository1.save(Cliente2);

			Account account1 = new Account("VIN001", 5000.0, LocalDateTime.now(), Cliente1);
			Account account2 = new Account("VIN002", 7500.0, LocalDateTime.now().plusDays(1), Cliente1);
			Account account3 = new Account("VIN003", 9000.0, LocalDateTime.now(), Cliente2);
			Account account4 = new Account("VIN004", 10500.0, LocalDateTime.now().plusDays(1), Cliente2);

			repository2.save(account1);
			repository2.save(account2);
			repository2.save(account3);
			repository2.save(account4);

			Transaction transaction1 = new Transaction(25000, "Bought the Microprocesator", LocalDateTime.now(), Type.CREDIT, account1);
			Transaction transaction2 = new Transaction(38000, "Bought the Microprocesator", LocalDateTime.now(), Type.DEBIT, account1);
			Transaction transaction3 = new Transaction(73540, "Bought the Motherboard", LocalDateTime.now(), Type.DEBIT, account2);
			Transaction transaction4 = new Transaction(15000, "Bought the Microprocesator", LocalDateTime.now(), Type.CREDIT, account2);

			repository3.save(transaction1);
			repository3.save(transaction2);
			repository3.save(transaction3);
			repository3.save(transaction4);

		};

	}
}
