Vue.createApp({
    data() {
      return {
        datos: [],
        datosCliente: [],
        nombreCliente: "",
      };
    },
  
    created() {
      const urlParams = new URLSearchParams(window.location.search);
      const id = urlParams.get('id');
      axios.get(`http://localhost:8080/api/clients/${id}`).then((data) => {        
        console.log(data)
        this.datos = data.data.accounts
        this.nombreCliente = data.data.firstName + " " + data.data.lastName 
        console.log(this.datosCliente)
        console.log(this.datos)

        feather.replace()

      });
    },
    methods: {

      

    },
    computed: {},
  }).mount("#app");