package com.mindhub.Homebanking.Controllers;

import com.mindhub.Homebanking.dtos.AccountDTO;
import com.mindhub.Homebanking.dtos.ClientLoanDTO;
import com.mindhub.Homebanking.dtos.LoanApplicationDTO;
import com.mindhub.Homebanking.dtos.LoanDTO;
import com.mindhub.Homebanking.models.*;
import com.mindhub.Homebanking.repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

@RequestMapping("/api")
@RestController
public class LoanController {

    @Autowired
    LoanRepository loanRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    TransactionRepository transactionRepository;

    @Autowired
    ClientLoanRepository clientLoanRepository;

    @RequestMapping("/loans")
    public List<LoanDTO> getAll(){
        return loanRepository.findAll().stream().map(LoanDTO::new).collect(Collectors.toList());
    }

    @Transactional
    @PostMapping("/loans")
    public ResponseEntity<Object> createLoan(Authentication authentication, @RequestBody LoanApplicationDTO loanApplicationDTO) {

        Client client = clientRepository.findByEmail(authentication.getName());

        String destination_account_number = loanApplicationDTO.getDestination_account();
        int payments = loanApplicationDTO.getPayments();
        Double amount = loanApplicationDTO.getAmount();

        Loan currentLoan = loanRepository.findById(loanApplicationDTO.getId()).orElse(null);
        Double maxAmount = currentLoan.getMaxAmount();
        Long typeLoan = currentLoan.getId();

        Account currentAccount = accountRepository.findByNumber(destination_account_number);

        if(client.getLoans().stream().filter(loan -> loan.getId() == loanApplicationDTO.getId()).collect(Collectors.toSet()).size() > 0) {
            return new ResponseEntity<>("The client has already applied for this loan", HttpStatus.FORBIDDEN);
        }

        if (destination_account_number.isEmpty()) {
            return new ResponseEntity<>("Destination account empty", HttpStatus.FORBIDDEN);
        }

        if (amount <= 0) {
            return new ResponseEntity<>("Amount can't be equal or minus to 0", HttpStatus.FORBIDDEN);
        }

        if (payments <= 0) {
            return new ResponseEntity<>("Payments can´t be equal or minus to 0", HttpStatus.FORBIDDEN);
        }

        if (!loanRepository.findAll().stream().map(Loan::getId).collect(Collectors.toSet()).contains(typeLoan)) {
            return new ResponseEntity<>("The loan doesn't exist", HttpStatus.FORBIDDEN);
        }

        if (maxAmount < amount) {
            return new ResponseEntity<>("The requested amount exceeds the maximum allowed", HttpStatus.FORBIDDEN);
        }

        if (!currentLoan.getPayments().contains(payments)) {
            return new ResponseEntity<>("Requested quotas are not a valid option", HttpStatus.FORBIDDEN);
        }

        if (accountRepository.findByNumber(destination_account_number) == null) {
            return new ResponseEntity<>("The account doesn't exist", HttpStatus.FORBIDDEN);
        }

        if (!client.getAccounts().stream().map(Account::getNumber).collect(Collectors.toSet()).contains(destination_account_number)) {
            return new ResponseEntity<>("The client don't have that account", HttpStatus.FORBIDDEN);
        }

        Double amountPercent = amount + (amount * 20/100);
        currentAccount.setBalance(currentAccount.getBalance() + amount);
        accountRepository.save(currentAccount);

        Transaction transaction = new Transaction(amount, destination_account_number + " " + "Loan aprovved", LocalDateTime.now(),  Type.CREDIT, currentAccount);
        transactionRepository.save(transaction);

        ClientLoan clientLoan = new ClientLoan(amountPercent, payments, currentLoan, client);
        clientLoanRepository.save(clientLoan);

        return new ResponseEntity<>("Loan has been complete", HttpStatus.CREATED);
    }


}
