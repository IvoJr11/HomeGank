package com.mindhub.Homebanking.models;

public enum CardType {
    CREDIT,
    DEBIT,
}
