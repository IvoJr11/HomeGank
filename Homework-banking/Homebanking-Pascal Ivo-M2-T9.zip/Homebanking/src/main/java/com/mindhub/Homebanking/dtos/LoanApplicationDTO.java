package com.mindhub.Homebanking.dtos;

import com.mindhub.Homebanking.models.ClientLoan;
import com.mindhub.Homebanking.models.Transaction;

public class LoanApplicationDTO {

    private long id;

    private Double amount;

    private int payments;

    private String destination_account;

    public LoanApplicationDTO() {};

    public LoanApplicationDTO (ClientLoan clientloan, Transaction transaction) {

        this.id = clientloan.getLoan().getId();
        this.amount = clientloan.getAmount();
        this.payments = clientloan.getPayments();
        this.destination_account = transaction.getAccount().getNumber();

    }

    public long getId() {return id;}

    public Double getAmount() {return amount;}

    public int getPayments() {return payments;}

    public String getDestination_account() {return destination_account;}
}
