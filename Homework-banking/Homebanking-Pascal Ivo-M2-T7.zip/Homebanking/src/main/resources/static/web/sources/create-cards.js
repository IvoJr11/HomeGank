const vue = Vue.createApp({
    data() {
      return {
        type: "",
        color: "",
        color_selected: "",
      };
    },
  
    created() {

    },
    methods: {
        create() {
            axios.post('/api/clients/current/cards',`type=${this.type}&color=${this.color}`,{headers:{'content-type':'application/x-www-form-urlencoded'}})
            .then(response => console.log(response))
            .then(response => location.href="http://localhost:8080/web/cards.html")
        },

        back() {
          location.href="http://localhost:8080/web/cards.html"
        },

        titanium() {
          this.color_selected = "TITANIUM"
          console.log(this.color_selected)
        },

        gold() {
          this.color_selected = "GOLD"
          console.log(this.color_selected)
        },

        silver() {
          this.color_selected = "SILVER"
          console.log(this.color_selected)
        }
    },
    computed: {
        
    },
  }).mount("#app");