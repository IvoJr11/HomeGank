package com.mindhub.Homebanking.Controllers;

import com.mindhub.Homebanking.models.Account;
import com.mindhub.Homebanking.models.Transaction;
import com.mindhub.Homebanking.models.Type;
import com.mindhub.Homebanking.repositories.AccountRepository;
import com.mindhub.Homebanking.repositories.ClientRepository;
import com.mindhub.Homebanking.repositories.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class TransactionController {

    @Autowired
    ClientRepository clientRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    TransactionRepository transactionRepository;

    @Transactional
    @PostMapping("/transactions")
    public ResponseEntity<Object> transaction(Authentication authentication,
    @RequestParam Double amount, @RequestParam String description, @RequestParam String source_number, @RequestParam String destination_number) {

        Account accountDebit = accountRepository.findByNumber(source_number);
        Account accountCredit = accountRepository.findByNumber(destination_number);

        if (amount <= 0) {
            return new ResponseEntity<>("Amount can't be 0 or minus", HttpStatus.FORBIDDEN);
        }

        if (description.isEmpty()) {
            return new ResponseEntity<>("Description is empty", HttpStatus.FORBIDDEN);
        }

        if (source_number.isEmpty()) {
            return new ResponseEntity<>("Origin account is empty", HttpStatus.FORBIDDEN);
        }

        if (destination_number.isEmpty()) {
            return new ResponseEntity<>("Destination account is empty", HttpStatus.FORBIDDEN);
        }

        if (source_number.equals(destination_number)) {
            return new ResponseEntity<>("The first account's number is the same of second account's number", HttpStatus.FORBIDDEN);
        }

        if (accountDebit == null) {
            return new ResponseEntity<>("The account does not exist", HttpStatus.FORBIDDEN);
        }

        if (!clientRepository.findByEmail(authentication.getName()).getAccounts().stream().map(Account::getNumber).collect(Collectors.toSet()).contains(source_number)) {
            return new ResponseEntity<>("The account does not belong", HttpStatus.FORBIDDEN);
        }

        if (accountCredit == null) {
            return new ResponseEntity<>("The account does not exist", HttpStatus.FORBIDDEN);
        }

        if (accountDebit.getBalance() < amount) {
            return new ResponseEntity<>("The account don't have enough amount", HttpStatus.FORBIDDEN);
        }

        Double debitBalance = (accountDebit.getBalance() - amount);
        Double creditBalance = (accountCredit.getBalance() + amount);

        accountDebit.setBalance(debitBalance);
        accountCredit.setBalance(creditBalance);

        accountRepository.save(accountDebit);
        accountRepository.save(accountCredit);

        Transaction transactionDebit = new Transaction(amount, description + accountCredit.getNumber(), LocalDateTime.now(), Type.DEBIT, accountDebit);
        Transaction transactionCredit = new Transaction(amount, description + accountDebit.getNumber(), LocalDateTime.now(), Type.CREDIT, accountCredit);

        transactionRepository.save(transactionCredit);
        transactionRepository.save(transactionDebit);

        return new ResponseEntity<>("Transaction has been complete", HttpStatus.CREATED);

    }
}
