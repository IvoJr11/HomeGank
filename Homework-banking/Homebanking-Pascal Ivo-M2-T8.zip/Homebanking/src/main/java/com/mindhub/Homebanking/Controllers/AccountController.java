package com.mindhub.Homebanking.Controllers;

import com.mindhub.Homebanking.dtos.AccountDTO;
import com.mindhub.Homebanking.dtos.ClientDTO;
import com.mindhub.Homebanking.models.Account;
import com.mindhub.Homebanking.models.Client;
import com.mindhub.Homebanking.repositories.AccountRepository;
import com.mindhub.Homebanking.repositories.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

import static com.mindhub.Homebanking.Utils.Utils.getRandomNumber;
import static java.util.stream.Collectors.toList;

@RestController
@RequestMapping("/api")
public class AccountController {

    @Autowired
    private AccountRepository accountRepository;

    @RequestMapping("/accounts")
    public List<AccountDTO> getAll(){
        return accountRepository.findAll().stream().map(AccountDTO::new).collect(toList());
    }

    @RequestMapping("accounts/{id}")
    public AccountDTO getAccount(@PathVariable Long id){

        return accountRepository.findById(id).map(AccountDTO::new).orElse(null);

    }

    @Autowired
    private ClientRepository clientRepository;

    @RequestMapping(path="/clients/current/accounts", method = RequestMethod.POST)
    public ResponseEntity<Object> createAccount(Authentication authentication) {
        Client client = clientRepository.findByEmail(authentication.getName());
        List <Account> accounts = accountRepository.findByClient(client);

        if(accounts.size() < 3) {
        accountRepository.save(new Account("VIN-" + getRandomNumber(0, 99999999), 0.0, LocalDateTime.now(), client));
        return new ResponseEntity<>("Account created", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("The client can't have more of 3 accounts", HttpStatus.FORBIDDEN);
        }

        //if (accounts.size() > 2) {
        //    return new ResponseEntity<>("The client can't have more of 3 accounts", HttpStatus.FORBIDDEN);
        //}
    }
}
