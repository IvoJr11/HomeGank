package com.mindhub.Homebanking.Controllers;

import com.mindhub.Homebanking.dtos.CardDTO;
import com.mindhub.Homebanking.dtos.ClientDTO;
import com.mindhub.Homebanking.dtos.ClientLoanDTO;
import com.mindhub.Homebanking.models.Card;
import com.mindhub.Homebanking.models.CardColor;
import com.mindhub.Homebanking.models.CardType;
import com.mindhub.Homebanking.models.Client;
import com.mindhub.Homebanking.repositories.CardRepository;
import com.mindhub.Homebanking.repositories.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import static com.mindhub.Homebanking.Utils.Utils.getRandomNumber;
import static java.util.stream.Collectors.toList;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class CardController {

    @RequestMapping("clients/current/cards")
    public List<CardDTO> getCards(Authentication authentication){
        Client client = clientRepository.findByEmail(authentication.getName());
        return client.getCards().stream().map(CardDTO::new).collect(Collectors.toList());
    }

    @Autowired
    ClientRepository clientRepository;
    @Autowired
    CardRepository cardRepository;

    @RequestMapping(path = "/clients/current/cards", method = RequestMethod.POST)
    private ResponseEntity<Object> CardCreator(
            Authentication authentication, @RequestParam CardType type, @RequestParam CardColor color) {

        Client client = clientRepository.findByEmail(authentication.getName());

        if(client.getCards().stream().filter(card -> (card.getType().toString().equals(type.toString()))).collect(Collectors.toList()).size() >= 3) {

            return new ResponseEntity<>("The client can't 3 or more cards of this type", HttpStatus.FORBIDDEN);
        }

        String cardNumber = getRandomNumber(1000, 9999) + "-" + getRandomNumber(1000, 9999) + "-" + getRandomNumber(1000, 9999) + "-" + getRandomNumber(1000, 9999);

        cardRepository.save(new Card(client, color, type, cardNumber, getRandomNumber(100, 999), LocalDateTime.now(), LocalDateTime.now().plusYears(5)));
        return new ResponseEntity<>("Card has created successfully", HttpStatus.CREATED);
    }
}
