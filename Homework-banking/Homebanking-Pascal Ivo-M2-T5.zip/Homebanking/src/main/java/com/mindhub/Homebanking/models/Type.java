package com.mindhub.Homebanking.models;

public enum Type {
    CREDIT,
    DEBIT
}
