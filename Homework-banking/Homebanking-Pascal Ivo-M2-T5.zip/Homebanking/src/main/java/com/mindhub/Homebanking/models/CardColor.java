package com.mindhub.Homebanking.models;

public enum CardColor {
    GOLD,
    SILVER,
    TITANIUM,
}
