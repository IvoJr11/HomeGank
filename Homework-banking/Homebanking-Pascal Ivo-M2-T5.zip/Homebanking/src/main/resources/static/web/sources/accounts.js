Vue.createApp({
    data() {
      return {
        datos: [],
        datosCliente: [],
        nombreCliente: "",
        loans: [],
      };
    },
  
    created() {
      const urlParams = new URLSearchParams(window.location.search);
      const id = urlParams.get('id');
      axios.get(`http://localhost:8080/api/clients/${id}`).then((data) => {        
        console.log(data)
        this.datos = data.data.accountsDTO.sort((a, b) => a.id - b.id)
        this.nombreCliente = data.data.firstName + " " + data.data.lastName 
        this.loans = data.data.loans.sort((a, b) => a.id - b.id)
        console.log(this.datosCliente)
        console.log(this.datos)
        console.log(this.loans)

        feather.replace()

      });
    },
    methods: {

      

    },
    computed: {},
  }).mount("#app");