Vue.createApp({
    data() {
      return {
        datos: [],
        datosCliente: [],
        nombreCliente: "",
        loans: [],
      };
    },
  
    created() {
      axios.get("http://localhost:8080/api/clients/current").then((data) => {        
        console.log(data)
        this.datosCliente = data.data
        this.datos = data.data.accountsDTO.sort((a, b) => a.id - b.id)
        this.nombreCliente = data.data.firstName + " " + data.data.lastName 
        this.loans = data.data.loans.sort((a, b) => a.id - b.id)
        console.log(this.datosCliente)
        console.log(this.datos)
        console.log(this.loans)
      });
    },
    methods: {

      logOut() {
        axios.post('/api/logout')
        .then(response => location.href="http://localhost:8080/web/index.html")
        .then(response => console.log('signed out!!!'))
    }

    },
    computed: {},
  }).mount("#app");

  $('article.tile').click(function() {
      $('article.tile').animate({width: "600px"}, 200)
  })