Vue.createApp({
    data() {
      return {
        datos: [],
        datosCliente: [],
        nombreCliente: "",
        transactions: [],
        dataAccount: [],
        
      };
    },
  
    created() {

        const urlParams = new URLSearchParams(window.location.search);
        const id = urlParams.get('id');

        axios.get("http://localhost:8080/api/clients/current").then((data) => {
            console.log(data)
            this.datos = data.data
            console.log(this.datos)
        });
        axios.get(`http://localhost:8080/api/accounts/${id}`).then((data2) => {        
            this.dataAccount = data2.data
            console.log(this.dataAccount)
            this.transactions = this.dataAccount.transactionsDTO.sort((a,b)=> a-b)
            console.log(this.transactions)

        });
    },
        
    methods: {

      getDate (dateInput) {
        const date = new Date(dateInput)
        const formatDate = (date.getMonth() + 1) + "/" + date.getDate()  + "/" + date.getFullYear() + " "  + date.getHours() + ":" + date.getMinutes()
        return formatDate
      },

      logOut() {
        axios.post('/api/logout')
        .then(response => location.href="http://localhost:8080/web/index.html")
        .then(response => console.log('signed out!!!'))
      }

    },
    computed: {

      colorTabla: function (transaction) {
        return [
          'table-primary',
          transaction.type = "CREDIT"
        ]
      }
    },
  }).mount("#app");