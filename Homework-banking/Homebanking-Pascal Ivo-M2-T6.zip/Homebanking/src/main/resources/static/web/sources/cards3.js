Vue.createApp({
    data() {
      return {
        datos: [],
        clientCards: [],
        creditCards: [],
        debitCards: [],
      };
    },
  
    created() {

            axios.get("http://localhost:8080/api/clients/current").then((data) => {
                console.log(data)
                this.datos = data.data
                console.log(this.datos)
    
                this.clientCards = this.datos.cards.sort((a, b) => a.id - b.id)
                console.log(this.clientCards)
    
                this.creditCards = this.clientCards.filter(card => card.type == "CREDIT").sort((a, b) => a.id - b.id)
                this.debitCards = this.clientCards.filter(card => card.type == "DEBIT").sort((a, b) => a.id - b.id)
    
                console.log(this.creditCards)
                console.log(this.debitCards)
                
                
            });

    },
        
    methods: {

        logOut() {
            axios.post('/api/logout')
            .then(response => location.href="http://localhost:8080/web/index.html")
            .then(response => console.log('signed out!!!'))
        },

        getDate (dateInput) {
            const date = new Date(dateInput)
            const year = date.getFullYear().toString()
            const yearTwo = year.substr(year.length - 2)
            const formatDate = (date.getMonth() + 1) + "/" + yearTwo
            return formatDate
        },

    },
    computed: {


    },
  }).mount("#app");

$("#alert").click(function() {
  Swal.fire('Any fool can use a computer')
})