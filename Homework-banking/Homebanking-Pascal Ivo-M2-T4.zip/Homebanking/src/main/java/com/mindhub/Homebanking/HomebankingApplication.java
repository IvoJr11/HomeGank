package com.mindhub.Homebanking;

import com.mindhub.Homebanking.models.*;
import com.mindhub.Homebanking.repositories.*;
import org.apache.tomcat.jni.Local;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class HomebankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomebankingApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(ClientRepository repository1, AccountRepository repository2, TransactionRepository repository3, LoanRepository repository4, ClientLoanRepository repository5) {
		return (args) -> {

			Client Client1 = new Client("Melba", "Morel", "melba@mindhub.com");
			Client  Client2= new Client ("Pedro", "Hernández", "pedrohf@gmail.com");

			repository1.save(Client1);
			repository1.save(Client2);

			Account account1 = new Account("VIN001", 5000.0, LocalDateTime.now(), Client1);
			Account account2 = new Account("VIN002", 7500.0, LocalDateTime.now().plusDays(1), Client1);
			Account account3 = new Account("VIN003", 9000.0, LocalDateTime.now(), Client2);
			Account account4 = new Account("VIN004", 10500.0, LocalDateTime.now().plusDays(1), Client2);

			repository2.save(account1);
			repository2.save(account2);
			repository2.save(account3);
			repository2.save(account4);

			Transaction transaction1 = new Transaction(25000, "Bought the Microprocesator", LocalDateTime.now(), Type.CREDIT, account1);
			Transaction transaction2 = new Transaction(38000, "Bought the Microprocesator", LocalDateTime.now(), Type.DEBIT, account1);
			Transaction transaction3 = new Transaction(73540, "Bought the Motherboard", LocalDateTime.now(), Type.DEBIT, account2);
			Transaction transaction4 = new Transaction(15000, "Bought the Microprocesator", LocalDateTime.now(), Type.CREDIT, account2);

			repository3.save(transaction1);
			repository3.save(transaction2);
			repository3.save(transaction3);
			repository3.save(transaction4);

			Loan loan1 = new Loan("Hipotecario", 500000, List.of(12,24,36,48,60));
			Loan loan2 = new Loan("Personal", 100000, List.of(6,12,24));
			Loan loan3 = new Loan("Automotriz", 300000, List.of(6,12,24,36));

			repository4.save(loan1);
			repository4.save(loan2);
			repository4.save(loan3);

			ClientLoan clientLoan1 = new ClientLoan(400000, 60, loan1, Client1);
			ClientLoan clientLoan2 = new ClientLoan(50000, 12, loan2, Client1);
			ClientLoan clientLoan3 = new ClientLoan(100000, 24, loan2, Client2);
			ClientLoan clientLoan4 = new ClientLoan(200000, 36, loan3, Client2);

			repository5.save(clientLoan1);
			repository5.save(clientLoan2);
			repository5.save(clientLoan3);
			repository5.save(clientLoan4);

		};

	}
}
