Vue.createApp({
    data() {
      return {
        datos: [],
        datosCliente: [],
        nombreCliente: "",
      };
    },
  
    created() {
      axios.get("http://localhost:8080/api/clients/1").then((data) => {        
        console.log(data)
        this.datos = data.data.accounts
        this.nombreCliente = data.data.firstName + " " + data.data.lastName 
        console.log(this.datosCliente)
        console.log(this.datos)

      });
    },
    methods: {

      

    },
    computed: {},
  }).mount("#app");