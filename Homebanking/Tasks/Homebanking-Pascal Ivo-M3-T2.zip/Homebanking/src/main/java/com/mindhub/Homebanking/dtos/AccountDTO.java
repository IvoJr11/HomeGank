package com.mindhub.Homebanking.dtos;

import com.mindhub.Homebanking.models.Account;

import java.time.LocalDateTime;

public class AccountDTO {
    private long id;
    private String Number;
    private Double Balance;
    private LocalDateTime creationDate;

    public AccountDTO () {}

    public AccountDTO (Account account) {
        this.id = account.getId();
        this.Number = account.getNumber();
        this.Balance = account.getBalance();
        this.creationDate = account.getCreationDate();
    }

    public long getId() {
        return id;
    }

    public String getNumber() {return Number;}
    public void setNumber(String number) {Number = number;}

    public Double getBalance() {return Balance;}
    public void setBalance(Double balance) {Balance = balance;}

    public LocalDateTime getCreationDate() {return creationDate;}
    public void setCreationDate(LocalDateTime creationDate) {this.creationDate = creationDate;}
}
