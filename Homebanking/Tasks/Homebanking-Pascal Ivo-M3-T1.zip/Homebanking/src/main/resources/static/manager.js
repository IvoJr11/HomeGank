Vue.createApp({
  data() {
    return {
      datos: [],
      clientes: [],
      firstname: "",
      lastname: "",
      email: "",
      firstnameEdit: "",
      lastnameEdit: "",
      emailEdit: "",
      urlClient: "",
      clienteSeleccionado: {}
    };
  },

  created() {
    axios.get("http://localhost:8080/clients").then((data) => {
      this.datos = data;
      this.clientes = this.datos.data._embedded.clients;
      console.log(this.clientes);
      this.firstname = document.querySelector("#firstname");
      this.lastname = document.querySelector("#lastname");
      this.email = document.querySelector("#email");

       

    });
  },

  methods: {

    llenandoTabla() {
      if (
        this.firstname.value != "" &&
        this.lastname.value != "" &&
        this.email.value != ""
      ){
        axios.post("http://localhost:8080/clients", {
            firstName: this.firstname.value,
            lastName: this.lastname.value,
            email: this.email.value,
          })
          .then(function (response) {
            console.log(response);
          });
        }
    },

    deleteClient(param) {
      axios.delete(param)
      location.reload();
    },

    editarCliente() {

      this.firstnameEdit = document.querySelector("#firstname2").value;
      this.lastnameEdit = document.querySelector("#lastname2").value;
      this.emailEdit = document.querySelector("#email2").value;

      console.log(this.firstnameEdit)
      console.log(this.lastnameEdit)
      console.log(this.emailEdit)

      axios.patch(this.urlClient, {
        firstName: this.firstnameEdit,
        lastName: this.lastnameEdit,
        email: this.emailEdit,
      })
      .then(function (response) {
        console.log(response);
      });

    },

    tomandoUrl(client) {
      
      this.clienteSeleccionado = client
      console.log(this.clienteSeleccionado)
      this.urlClient = client._links.client.href
      console.log(this.urlClient)
      
    }
  },

  computed: {},
}).mount("#app");
